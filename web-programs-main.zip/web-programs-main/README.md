# web-programs
web development
Assignment1.html output
![Screenshot 2023-06-16 140242](https://github.com/Keerti2024/web-programs/assets/136551293/06b035bc-7b56-4c58-9425-9d110d491955)

Assignment2.html output
![Screenshot 2023-06-16 141113](https://github.com/Keerti2024/web-programs/assets/136551293/57edb4f9-e3c6-43ac-9a10-93ab8b6049f8)

Assignment3_.html output

![Screenshot 2023-06-16 141711](https://github.com/Keerti2024/web-programs/assets/136551293/8fbe3381-4688-49c7-bf68-41a011146323)
![Screenshot 2023-06-16 141736](https://github.com/Keerti2024/web-programs/assets/136551293/1ed0e936-2aa6-4b40-9dd1-93e9e7220d21)

Assignment_4.html output
![Screenshot 2023-06-16 143221](https://github.com/Keerti2024/web-programs/assets/136551293/8df288e0-cf8d-4d86-8858-853ba93984e4)
![Screenshot 2023-06-16 143307](https://github.com/Keerti2024/web-programs/assets/136551293/3ca1ea09-e4fe-445c-86f5-85d9be4c1b3d)
![Screenshot 2023-06-16 143342](https://github.com/Keerti2024/web-programs/assets/136551293/e153e40f-1361-4426-aa68-0b6e44774a45)
![Screenshot 2023-06-16 143403](https://github.com/Keerti2024/web-programs/assets/136551293/670b3050-4a8d-40da-83f4-04e0f04100c8)

Assignment_5.xml output

![A5](https://github.com/Keerti2024/web-programs/assets/136551293/19d3d09c-fffd-4638-a0a3-96b263038f5b)

Assignment6.php output
![a6a](https://github.com/Keerti2024/web-programs/assets/136551293/b188d691-6786-41d2-af66-c08662370434)
![a6b](https://github.com/Keerti2024/web-programs/assets/136551293/1ae4533d-e9ae-44f9-aee9-37b7b7015bbe)

Assignment7.php output
![7a](https://github.com/Keerti2024/web-programs/assets/136551293/16d6fc97-89e3-4296-b45a-3b0fbe5d0f88)

Assignment8a.php output
![8aa](https://github.com/Keerti2024/web-programs/assets/136551293/c745d3db-1677-446f-8360-e304af2c1b21)
![8ab](https://github.com/Keerti2024/web-programs/assets/136551293/919fc587-9497-4e35-9626-82d2a7027fbd)

Assignment8b.php output
![8b](https://github.com/Keerti2024/web-programs/assets/136551293/563b071b-1599-493b-a378-56720f559a63)
